import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Define any API routes here if needed
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', message: 'Ooredoo Kuwait landing page server is running' });
  });
  
  // For a static landing page, we don't need many API endpoints
  // Add more as required - customer inquiries, subscriptions, etc.
  
  const httpServer = createServer(app);

  return httpServer;
}
