export const features = [
  {
    id: 1,
    title: "باقات الجوال المرنة",
    description:
      "باقات متنوعة تناسب احتياجاتك مع إنترنت لا محدود ومكالمات مجانية",
    icon: "Phone",
  },
  {
    id: 2,
    title: "إنترنت فائق السرعة",
    description:
      "سرعات تحميل عالية وتغطية ممتازة في جميع أنحاء الكويت",
    icon: "Globe",
  },
  {
    id: 3,
    title: "حماية وخصوصية",
    description:
      "نوفر أعلى مستويات الحماية والخصوصية لجميع مستخدمينا",
    icon: "Shield",
  },
];

export const offers = [
  {
    id: 1,
    title: "باقة الإنترنت المنزلي",
    discount: "50%",
    originalPrice: "25 د.ك/شهر",
    discountedPrice: "12.5 د.ك/شهر",
    features: [
      "سرعات تصل إلى 1 جيجابت في الثانية",
      "بيانات غير محدودة",
      "خدمة العملاء على مدار الساعة",
      "تركيب مجاني",
    ],
  },
  {
    id: 2,
    title: "باقة الهاتف الشاملة",
    discount: "40%",
    originalPrice: "20 د.ك/شهر",
    discountedPrice: "12 د.ك/شهر",
    features: [
      "بيانات غير محدودة للإنترنت",
      "مكالمات محلية غير محدودة",
      "100 دقيقة مكالمات دولية",
      "اشتراك مجاني في خدمات الترفيه",
    ],
  },
];

export const testimonials = [
  {
    id: 1,
    name: "أحمد السالم",
    since: "2019",
    comment: "خدمة ممتازة وسرعة إنترنت رائعة، أنا سعيد جدًا باختياري لـ Ooredoo لتلبية احتياجاتي من خدمات الاتصالات.",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
  },
  {
    id: 2,
    name: "سارة العنزي",
    since: "2021",
    comment: "العروض الحصرية من Ooredoo وفرت لي الكثير من المال، والتغطية ممتازة في جميع أنحاء الكويت.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
  },
  {
    id: 3,
    name: "محمد الفضلي",
    since: "2020",
    comment: "خدمة العملاء ممتازة ودائمًا ما يقدمون الحلول المناسبة. أنصح الجميع بالتعامل مع Ooredoo.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
  },
];

export const navLinks = [
  { name: "الرئيسية", href: "#" },
  { name: "العروض", href: "#offers" },
  { name: "الباقات", href: "#features" },
  { name: "خدمات العملاء", href: "#testimonials" },
  { name: "تواصل معنا", href: "#footer" },
];

export const footerLinks = {
  about: [
    { name: "من نحن", href: "#" },
    { name: "رؤيتنا", href: "#" },
    { name: "فريق العمل", href: "#" },
    { name: "الوظائف", href: "#" },
  ],
  services: [
    { name: "باقات الجوال", href: "#" },
    { name: "خدمات الإنترنت", href: "#" },
    { name: "العروض الحصرية", href: "#" },
    { name: "الأجهزة", href: "#" },
  ],
  support: [
    { name: "خدمة العملاء", href: "#" },
    { name: "الأسئلة الشائعة", href: "#" },
    { name: "اتصل بنا", href: "#" },
    { name: "فروعنا", href: "#" },
  ],
};

export const ctaContent = {
  title: "احصل على العروض الحصرية الآن",
  description:
    "لا تفوت فرصة الاستفادة من عروضنا الحصرية، سارع بالاشتراك الآن!",
  buttonText: "اشترك الآن واحصل على خصم إضافي",
  buttonUrl:
    "https://sites.google.com/view/oreoodo/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9",
};
