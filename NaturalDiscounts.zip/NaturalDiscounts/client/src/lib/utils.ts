import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Smooth scroll function for anchor links
export function smoothScroll(targetId: string) {
  const targetElement = document.querySelector(targetId);
  
  if (targetElement) {
    window.scrollTo({
      top: targetElement.getBoundingClientRect().top + window.pageYOffset - 80, // Account for fixed header
      behavior: 'smooth'
    });
  }
}
