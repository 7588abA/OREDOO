import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import FeaturesSection from "@/components/FeaturesSection";
import OffersSection from "@/components/OffersSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import CtaSection from "@/components/CtaSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      <Navbar />
      <Hero />
      <FeaturesSection />
      <OffersSection />
      <TestimonialsSection />
      <CtaSection />
      <Footer />
    </div>
  );
}
