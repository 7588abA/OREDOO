import { useState } from "react";
import { Button } from "@/components/ui/button";
import { navLinks } from "@/lib/data";
import { Menu, X } from "lucide-react";
import { smoothScroll } from "@/lib/utils";

const OoredooLogo = () => (
  <svg 
    width="120" 
    height="40" 
    viewBox="0 0 120 40" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle cx="20" cy="20" r="20" fill="#ED1C24" />
    <path d="M31 20C31 25.5228 26.5228 30 21 30C15.4772 30 11 25.5228 11 20C11 14.4772 15.4772 10 21 10C26.5228 10 31 14.4772 31 20Z" stroke="white" strokeWidth="2" />
    <text x="45" y="25" fill="#ED1C24" fontFamily="Arial" fontSize="16" fontWeight="bold">Ooredoo</text>
  </svg>
);

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavLinkClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute('href');
    if (href && href.startsWith('#')) {
      smoothScroll(href);
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <OoredooLogo />
            </div>
          </div>
          <div className="flex items-center">
            <div className="hidden md:block">
              <div className="flex items-baseline space-x-4 space-x-reverse">
                {navLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.href}
                    onClick={handleNavLinkClick}
                    className={`px-3 py-2 ${
                      index === 0
                        ? "text-[#ED1C24] font-medium"
                        : "text-[#333333] hover:text-[#ED1C24]"
                    } transition-colors duration-200`}
                  >
                    {link.name}
                  </a>
                ))}
              </div>
            </div>
          </div>
          <div className="flex items-center md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6 text-[#333333]" />
              ) : (
                <Menu className="h-6 w-6 text-[#333333]" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white p-4 shadow-lg">
          <div className="flex flex-col space-y-2">
            {navLinks.map((link, index) => (
              <a
                key={index}
                href={link.href}
                onClick={handleNavLinkClick}
                className={`px-3 py-2 ${
                  index === 0
                    ? "text-[#ED1C24] font-medium"
                    : "text-[#333333] hover:text-[#ED1C24]"
                } text-lg transition-colors duration-200`}
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
