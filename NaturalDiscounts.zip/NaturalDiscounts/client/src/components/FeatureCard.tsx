import { LucideIcon } from "lucide-react";
import { Phone, Globe, Shield } from "lucide-react";

interface FeatureCardProps {
  title: string;
  description: string;
  icon: string;
}

export default function FeatureCard({ title, description, icon }: FeatureCardProps) {
  const getIcon = (): LucideIcon => {
    switch (icon) {
      case "Phone":
        return Phone;
      case "Globe":
        return Globe;
      case "Shield":
        return Shield;
      default:
        return Shield;
    }
  };

  const Icon = getIcon();

  return (
    <div className="bg-[#F8F8F8] rounded-xl p-6 shadow-md transform transition duration-300 hover:scale-105">
      <div className="rounded-full bg-white p-3 w-16 h-16 flex items-center justify-center mx-auto mb-4">
        <Icon className="h-8 w-8 text-[#ED1C24]" />
      </div>
      <h3 className="text-xl font-bold text-[#333333] text-center mb-2">{title}</h3>
      <p className="text-gray-600 text-center">{description}</p>
    </div>
  );
}
