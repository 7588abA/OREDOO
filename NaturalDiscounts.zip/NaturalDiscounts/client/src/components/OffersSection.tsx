import OfferCard from "./OfferCard";
import { offers } from "@/lib/data";

export default function OffersSection() {
  return (
    <section id="offers" className="py-16 bg-[#F8F8F8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-[#333333] mb-4">عروض حصرية لفترة محدودة</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            استفد من خصوماتنا الحصرية واستمتع بأفضل خدمات الاتصالات
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {offers.map((offer) => (
            <OfferCard
              key={offer.id}
              title={offer.title}
              discount={offer.discount}
              originalPrice={offer.originalPrice}
              discountedPrice={offer.discountedPrice}
              features={offer.features}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
