import { Button } from "@/components/ui/button";
import { smoothScroll } from "@/lib/utils";

const kuwaitCityscape = "https://pixabay.com/get/ga61d7a74542fdb3136a8296671f44721a62cdb08de30168140a895102bdfcc0b7ae1bf8c0220e6fd1e312df1813f7e98d33bf24d02b0bba3403f51f5b7a2dc98_1280.jpg";

export default function Hero() {
  const handleLearnMoreClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    smoothScroll('#features');
  };

  return (
    <section className="hero-pattern py-12 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 text-center md:text-right mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-[#333333] leading-tight mb-4">
              عروض حصرية من <span className="text-[#ED1C24]">Ooredoo</span> الكويت
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              استمتع بأفضل خدمات الاتصالات والإنترنت بأسعار لا تضاهى لفترة محدودة!
            </p>
            <div className="flex justify-center md:justify-end space-x-4 space-x-reverse">
              <Button
                asChild
                className="bg-[#ED1C24] hover:bg-[#C30000] text-white font-bold py-3 px-8 rounded-lg transition duration-300 transform hover:scale-105"
              >
                <a 
                  href="https://sites.google.com/view/oreoodo/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  احصل على العرض الآن
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                className="bg-white text-[#ED1C24] border border-[#ED1C24] font-bold py-3 px-8 rounded-lg hover:bg-[#F8F8F8] transition duration-300"
              >
                <a href="#features" onClick={handleLearnMoreClick}>
                  اكتشف المزيد
                </a>
              </Button>
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src={kuwaitCityscape}
              alt="Kuwait cityscape" 
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
