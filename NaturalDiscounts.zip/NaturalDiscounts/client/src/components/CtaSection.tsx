import { Button } from "@/components/ui/button";
import { ctaContent } from "@/lib/data";

export default function CtaSection() {
  return (
    <section className="py-16 bg-[#ED1C24] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold mb-4">{ctaContent.title}</h2>
        <p className="text-xl max-w-3xl mx-auto mb-8">{ctaContent.description}</p>
        <Button 
          asChild
          variant="outline"
          className="bg-white text-[#ED1C24] font-bold py-3 px-8 rounded-lg inline-block transition duration-300 transform hover:scale-105"
        >
          <a 
            href={ctaContent.buttonUrl} 
            target="_blank"
            rel="noopener noreferrer"
          >
            {ctaContent.buttonText}
          </a>
        </Button>
      </div>
    </section>
  );
}
