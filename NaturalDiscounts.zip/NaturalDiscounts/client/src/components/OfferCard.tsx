import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface OfferCardProps {
  title: string;
  discount: string;
  originalPrice: string;
  discountedPrice: string;
  features: string[];
}

export default function OfferCard({
  title,
  discount,
  originalPrice,
  discountedPrice,
  features,
}: OfferCardProps) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-2xl font-bold text-[#333333]">{title}</h3>
          <span className="bg-[#ED1C24] text-white text-sm font-bold py-1 px-3 rounded-full">
            خصم {discount}
          </span>
        </div>
        <ul className="space-y-2 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-600">
              <Check className="h-5 w-5 text-[#ED1C24] ml-2" />
              {feature}
            </li>
          ))}
        </ul>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-gray-500 line-through text-lg">{originalPrice}</span>
            <span className="text-[#ED1C24] font-bold text-2xl mr-2">{discountedPrice}</span>
          </div>
          <Button
            asChild
            className="bg-[#ED1C24] hover:bg-[#C30000] text-white font-bold py-2 px-6 rounded-lg transition duration-300"
          >
            <a
              href="https://sites.google.com/view/oreoodo/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9"
              target="_blank"
              rel="noopener noreferrer"
            >
              اشترك الآن
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
}
