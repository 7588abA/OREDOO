interface TestimonialCardProps {
  name: string;
  since: string;
  comment: string;
  image: string;
}

export default function TestimonialCard({
  name,
  since,
  comment,
  image,
}: TestimonialCardProps) {
  return (
    <div className="bg-[#F8F8F8] rounded-xl p-6 shadow-md">
      <div className="flex justify-center mb-4">
        <img
          src={image}
          alt={`صورة ${name}`}
          className="h-16 w-16 rounded-full object-cover"
        />
      </div>
      <p className="text-gray-600 text-center mb-4">"{comment}"</p>
      <h4 className="text-[#333333] font-bold text-center">{name}</h4>
      <p className="text-gray-500 text-sm text-center">عميل منذ {since}</p>
    </div>
  );
}
